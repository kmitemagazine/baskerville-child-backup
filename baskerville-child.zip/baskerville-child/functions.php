<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'baskerville_style','baskerville_style' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 20 );
function add_articles_to_homepage( $query ) {
if ( !is_admin() && is_home() && $query->is_main_query() ) {
$query->set( 'post_type', array( 'post', 'article') );
}
return $query;
}
add_action( 'pre_get_posts', 'add_articles_to_homepage' );
function issuem_post_author_archive( &$query )
{
    if ( $query->is_author )
        $query->set( 'post_type', 'article' && 'post' );	
    //remove_action( 'pre_get_posts', 'issuem_post_author_archive' ); // run once!
}
add_action( 'pre_get_posts', 'issuem_post_author_archive' );
// END ENQUEUE PARENT ACTION
?>